;;; gnopon-core.el --- Core GnoponEmacs kernel -*- lexical-binding: t; -*-

;;; Code:

(require 'package)
(require 'seq)
(require 'subr-x)
(require 'gnopon-lib)

(defgroup gnopon nil
  "Markdown-native engineering cockpit."
  :group 'convenience)

(defcustom gnopon-enable-eglot-auto nil
  "When non-nil, start Eglot automatically in supported programming buffers."
  :type 'boolean
  :group 'gnopon)

(defcustom gnopon-agent-command "codex"
  "Default project-scoped agent command."
  :type 'string
  :group 'gnopon)

(defvar gnopon-start-time (current-time)
  "Time when GnoponEmacs started loading.")

(defvar gnopon-state-dir (expand-file-name "var/" user-emacs-directory)
  "Generated state directory.")

(defvar gnopon-map (make-sparse-keymap)
  "Prefix map for GnoponEmacs cockpit commands.")

(define-key global-map (kbd "C-c g") gnopon-map)
(define-key global-map (kbd "M-SPC") gnopon-map)

(defvar gnopon-package-manifest
  '(ace-window
    apheleia
    avy
    cape
    consult
    consult-dir
    corfu
    dape
    diff-hl
    diminish
    dockerfile-mode
    doom-modeline
    eat
    embark
    embark-consult
    envrc
    expand-region
    forge
    gptel
    helpful
    jq-mode
    json-mode
    magit
    markdown-mode
    markdown-toc
    modus-themes
    multiple-cursors
    nerd-icons
    nerd-icons-completion
    nerd-icons-dired
    nix-mode
    no-littering
    orderless
    paredit
    popper
    restclient
    rust-mode
    transient
    treesit-auto
    typescript-mode
    vertico
    which-key
    yaml-mode
    yasnippet
    yasnippet-snippets)
  "Third-party packages expected by GnoponEmacs.")

(defun gnopon/path (&rest segments)
  "Return a path under `gnopon-state-dir' from SEGMENTS."
  (expand-file-name (mapconcat #'identity segments "/") gnopon-state-dir))

(defun gnopon/ensure-directory (directory)
  "Create DIRECTORY and return it."
  (make-directory directory t)
  directory)

(defun gnopon/project-root ()
  "Return the active project root or `default-directory'."
  (if-let ((project (project-current nil)))
      (project-root project)
    default-directory))

(defun gnopon/project-file (name)
  "Return project-local file NAME."
  (expand-file-name name (gnopon/project-root)))

(defun gnopon/report-startup ()
  "Report approximate startup time."
  (interactive)
  (message "GnoponEmacs loaded in %.3fs with %d garbage collections"
           (float-time (time-subtract (current-time) gnopon-start-time))
           gcs-done))

(defun gnopon/loaded-module-features ()
  "Return loaded GnoponEmacs feature names."
  (sort
   (mapcar #'symbol-name
           (seq-filter (lambda (feature)
                         (string-prefix-p "gnopon-" (symbol-name feature)))
                       features))
   #'string<))

(defun gnopon/performance-report-text ()
  "Return a Markdown runtime performance and startup report."
  (let* ((startup-seconds (float-time (time-subtract (current-time) gnopon-start-time)))
         (modules (gnopon/loaded-module-features)))
    (concat "# GnoponEmacs Performance Report\n\n"
            "- project: `" (file-truename (gnopon/project-root)) "`\n"
            "- generated: `" (format-time-string "%Y-%m-%d %H:%M:%S") "`\n"
            "- startup-seconds: `" (format "%.3f" startup-seconds) "`\n"
            "- garbage-collections: `" (number-to-string gcs-done) "`\n"
            "- gc-cons-threshold: `" (number-to-string gc-cons-threshold) "`\n"
            "- read-process-output-max: `" (number-to-string read-process-output-max) "`\n"
            "- package-quickstart: `" (format "%s" package-quickstart) "`\n"
            "- package-count: `" (number-to-string (length gnopon-package-manifest)) "`\n"
            "- loaded-gnopon-modules: `" (number-to-string (length modules)) "`\n"
            "- native-comp: `" (if (fboundp 'native-comp-available-p)
                                   (format "%s" (native-comp-available-p))
                                 "unavailable")
            "`\n"
            "- state-dir: `" gnopon-state-dir "`\n"
            "- package-dir: `" package-user-dir "`\n\n"
            "## Loaded Modules\n\n"
            (if modules
                (mapconcat (lambda (module) (format "- `%s`\n" module)) modules "")
              "- none\n")
            "\n## External Benchmark\n\n"
            "- no-network startup benchmark: `pnpm --dir apps/gnoponemacs benchmark -- --iterations 5 --json`\n"
            "- package verifier: `pnpm --dir apps/gnoponemacs test`\n"
            "- reproducibility verifier: `pnpm --dir apps/gnoponemacs repro -- --require-tools`\n")))

(defun gnopon/performance-report ()
  "Open a read-only GnoponEmacs performance report."
  (interactive)
  (let ((buffer (get-buffer-create "*gnopon-performance*")))
    (with-current-buffer buffer
      (read-only-mode -1)
      (erase-buffer)
      (insert (gnopon/performance-report-text))
      (when (fboundp 'gnopon/markdown-buffer-mode)
        (gnopon/markdown-buffer-mode))
      (goto-char (point-min))
      (read-only-mode 1))
    (pop-to-buffer buffer)))

(defun gnopon/performance-report-path ()
  "Return a project-local performance report path."
  (let ((dir (gnopon/project-file "logs/performance/")))
    (make-directory dir t)
    (expand-file-name
     (format "%s-performance.md" (format-time-string "%Y%m%d-%H%M%S"))
     dir)))

(defun gnopon/write-performance-report ()
  "Write a GnoponEmacs performance report under `logs/performance/'."
  (interactive)
  (let ((path (gnopon/performance-report-path)))
    (with-temp-file path
      (insert (gnopon/performance-report-text)))
    (find-file path)
    path))

(defun gnopon/open-module ()
  "Open a GnoponEmacs module."
  (interactive)
  (let* ((module-dir (expand-file-name "lisp/" gnopon/root))
         (file (completing-read "Module: " (directory-files module-dir nil "\\.el\\'") nil t)))
    (find-file (expand-file-name file module-dir))))

(dolist (directory '("var" "var/auto-save" "var/backup" "var/eln-cache" "var/packages"))
  (make-directory (expand-file-name directory user-emacs-directory) t))

(setq custom-file (expand-file-name "local.el" user-emacs-directory)
      package-user-dir (expand-file-name "var/packages/elpa/" user-emacs-directory)
      package-selected-packages gnopon-package-manifest
      package-quickstart nil
      package-archives '(("gnu" . "https://elpa.gnu.org/packages/")
                         ("nongnu" . "https://elpa.nongnu.org/nongnu/")
                         ("melpa" . "https://melpa.org/packages/")))

(package-initialize)

(unless (require 'use-package nil t)
  (unless (package-installed-p 'use-package)
    (package-refresh-contents)
    (package-install 'use-package)))

(eval-when-compile
  (require 'use-package))
(require 'use-package)

(setq use-package-always-ensure nil
      use-package-always-defer t
      use-package-expand-minimally t
      use-package-enable-imenu-support t)

(defun gnopon/optional-package-available-p (package)
  "Return non-nil when optional PACKAGE is available on `load-path'."
  (locate-library (symbol-name package)))

(defmacro gnopon/use-optional-package (name &rest args)
  "Declare optional package NAME with `use-package' and ARGS.
The declaration is skipped when NAME is not available, so package absence does
not abort GnoponEmacs startup."
  (declare (indent defun))
  `(use-package ,name
     :if (gnopon/optional-package-available-p ',name)
     ,@args))

(use-package no-littering
  :if (gnopon/optional-package-available-p 'no-littering)
  :demand t
  :custom
  (no-littering-etc-directory (expand-file-name "var/etc/" user-emacs-directory))
  (no-littering-var-directory (expand-file-name "var/no-littering/" user-emacs-directory)))

(use-package diminish
  :if (gnopon/optional-package-available-p 'diminish))

(unless (require 'transient nil t)
  (defmacro transient-define-prefix (name args &optional docstring &rest _body)
    "Define NAME as a non-fatal fallback command when transient is absent.
ARGS and DOCSTRING follow `defun'.  The transient body is ignored so modules can
still load before the optional `transient' package is installed."
    `(defun ,name ,args
       ,(or docstring "Fallback command for a missing transient menu.")
       (interactive)
       (message "GnoponEmacs: transient is unavailable; use direct C-c g keys or install the package closure.")))
  (provide 'transient))

(use-package emacs
  :ensure nil
  :defer nil
  :custom
  (ad-redefinition-action 'accept)
  (auto-save-default t)
  (backup-by-copying t)
  (create-lockfiles nil)
  (delete-by-moving-to-trash t)
  (enable-recursive-minibuffers t)
  (fill-column 88)
  (help-window-select t)
  (history-length 300)
  (indent-tabs-mode nil)
  (large-file-warning-threshold (* 100 1024 1024))
  (read-answer-short t)
  (read-process-output-max (* 1024 1024))
  (sentence-end-double-space nil)
  (use-dialog-box nil)
  (use-short-answers t)
  :config
  (setq-default tab-width 2)
  (set-language-environment "UTF-8")
  (prefer-coding-system 'utf-8-unix)
  (global-auto-revert-mode 1)
  (global-display-line-numbers-mode 1)
  (column-number-mode 1)
  (delete-selection-mode 1)
  (electric-pair-mode 1)
  (repeat-mode 1)
  (define-key global-map (kbd "C-c g") gnopon-map)
  (define-key global-map (kbd "M-SPC") gnopon-map)
  (define-key gnopon-map (kbd "d s") #'gnopon/report-startup)
  (define-key gnopon-map (kbd "d p") #'gnopon/performance-report)
  (define-key gnopon-map (kbd "d P") #'gnopon/write-performance-report)
  (define-key gnopon-map (kbd "d m") #'gnopon/open-module))

(defun gnopon/search-project (pattern &optional directory)
  "Search DIRECTORY for PATTERN using the best available project search backend."
  (interactive (list (read-regexp "Search project: ")))
  (let ((root (file-name-as-directory (or directory (gnopon/project-root)))))
    (cond
     ((fboundp 'consult-ripgrep)
      (consult-ripgrep root pattern))
     ((fboundp 'project-find-regexp)
      (let ((default-directory root))
        (project-find-regexp pattern)))
     ((fboundp 'rgrep)
      (rgrep pattern "*" root))
     (t
      (user-error "No project search backend available")))))

(defun gnopon/switch-buffer ()
  "Switch buffers through Consult when available, otherwise use built-in completion."
  (interactive)
  (if (fboundp 'consult-buffer)
      (consult-buffer)
    (switch-to-buffer (read-buffer "Buffer: " (other-buffer)))))

(when (file-readable-p custom-file)
  (load custom-file nil 'nomessage))

(add-hook 'emacs-startup-hook
          (lambda ()
            (setq gc-cons-threshold (* 64 1024 1024)
                  gc-cons-percentage 0.1)
            (gnopon/report-startup)))

(provide 'gnopon-core)
;;; gnopon-core.el ends here
