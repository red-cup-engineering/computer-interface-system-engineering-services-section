;;; gnopon-persistence.el --- Local state -*- lexical-binding: t; -*-

;;; Code:

(require 'gnopon-core)

(setq backup-directory-alist `(("." . ,(expand-file-name "var/backup/" user-emacs-directory)))
      auto-save-file-name-transforms `((".*" ,(expand-file-name "var/auto-save/" user-emacs-directory) t))
      auto-save-list-file-prefix (expand-file-name "var/auto-save/sessions-" user-emacs-directory)
      native-comp-eln-load-path (list (expand-file-name "var/eln-cache/" user-emacs-directory)))

(use-package savehist
  :ensure nil
  :demand t
  :custom
  (savehist-file (expand-file-name "var/savehist" user-emacs-directory))
  (savehist-additional-variables '(kill-ring search-ring regexp-search-ring))
  :config
  (savehist-mode 1))

(use-package saveplace
  :ensure nil
  :demand t
  :custom
  (save-place-file (expand-file-name "var/places" user-emacs-directory))
  :config
  (save-place-mode 1))

(use-package recentf
  :ensure nil
  :demand t
  :custom
  (recentf-save-file (expand-file-name "var/recentf" user-emacs-directory))
  (recentf-max-saved-items 500)
  :config
  (recentf-mode 1))

(provide 'gnopon-persistence)
;;; gnopon-persistence.el ends here
