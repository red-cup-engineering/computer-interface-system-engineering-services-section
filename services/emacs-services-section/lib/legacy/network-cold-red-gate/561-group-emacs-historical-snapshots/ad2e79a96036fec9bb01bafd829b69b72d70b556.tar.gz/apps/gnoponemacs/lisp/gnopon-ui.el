;;; gnopon-ui.el --- Cockpit UI -*- lexical-binding: t; -*-

;;; Code:

(require 'gnopon-core)

(use-package modus-themes
  :demand t
  :custom
  (modus-themes-bold-constructs t)
  (modus-themes-italic-constructs t)
  (modus-themes-mixed-fonts t)
  :config
  (load-theme 'modus-operandi t))

(use-package which-key
  :demand t
  :diminish
  :custom
  (which-key-idle-delay 0.35)
  (which-key-separator " -> ")
  :config
  (which-key-mode 1))

(use-package transient
  :demand t)

(use-package helpful
  :bind
  (([remap describe-function] . helpful-callable)
   ([remap describe-variable] . helpful-variable)
   ([remap describe-key] . helpful-key)
   ([remap describe-command] . helpful-command)))

(use-package nerd-icons
  :if (display-graphic-p))

(use-package doom-modeline
  :if (display-graphic-p)
  :custom
  (doom-modeline-height 24)
  (doom-modeline-buffer-file-name-style 'truncate-with-project)
  :config
  (doom-modeline-mode 1))

(provide 'gnopon-ui)
;;; gnopon-ui.el ends here
