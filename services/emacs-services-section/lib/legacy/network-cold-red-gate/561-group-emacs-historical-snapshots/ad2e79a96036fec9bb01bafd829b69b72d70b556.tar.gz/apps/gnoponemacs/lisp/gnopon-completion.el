;;; gnopon-completion.el --- Completion and navigation -*- lexical-binding: t; -*-

;;; Code:

(require 'gnopon-core)

(use-package vertico
  :demand t
  :custom
  (vertico-cycle t)
  (vertico-resize nil)
  :config
  (vertico-mode 1))

(use-package orderless
  :demand t
  :custom
  (completion-styles '(orderless basic))
  (completion-category-defaults nil)
  (completion-category-overrides '((file (styles partial-completion)))))

(use-package marginalia
  :demand t
  :config
  (marginalia-mode 1))

(use-package nerd-icons-completion
  :if (display-graphic-p)
  :after (marginalia nerd-icons)
  :config
  (nerd-icons-completion-mode 1)
  (add-hook 'marginalia-mode-hook #'nerd-icons-completion-marginalia-setup))

(use-package consult
  :bind
  (("C-s" . consult-line)
   ("C-c s r" . consult-ripgrep)
   ("C-c s b" . consult-buffer)
   ("C-c s i" . consult-imenu)
   ("C-c s o" . consult-outline)
   ("C-c s e" . consult-compile-error)))

(use-package embark
  :bind
  (("C-." . embark-act)
   ("C-;" . embark-dwim)
   ("C-h B" . embark-bindings)))

(use-package embark-consult
  :after (embark consult)
  :hook (embark-collect-mode . consult-preview-at-point-mode))

(use-package corfu
  :demand t
  :custom
  (corfu-auto t)
  (corfu-cycle t)
  (corfu-preview-current nil)
  :config
  (global-corfu-mode 1))

(use-package cape
  :init
  (add-to-list 'completion-at-point-functions #'cape-file)
  (add-to-list 'completion-at-point-functions #'cape-dabbrev))

(use-package project
  :ensure nil
  :bind-keymap
  ("C-c p" . project-prefix-map)
  :custom
  (project-switch-commands '((project-find-file "Find file")
                             (consult-ripgrep "Ripgrep")
                             (project-dired "Dired")
                             (project-eshell "Eshell")
                             (magit-project-status "Magit"))))

(use-package dired
  :ensure nil
  :commands dired
  :custom
  (dired-dwim-target t)
  (dired-kill-when-opening-new-dired-buffer t)
  (dired-listing-switches "-alh --group-directories-first"))

(use-package nerd-icons-dired
  :if (display-graphic-p)
  :hook (dired-mode . nerd-icons-dired-mode))

(use-package consult-dir
  :bind
  (("C-x C-d" . consult-dir)
   ("C-x C-j" . consult-dir-jump-file)))

(provide 'gnopon-completion)
;;; gnopon-completion.el ends here
