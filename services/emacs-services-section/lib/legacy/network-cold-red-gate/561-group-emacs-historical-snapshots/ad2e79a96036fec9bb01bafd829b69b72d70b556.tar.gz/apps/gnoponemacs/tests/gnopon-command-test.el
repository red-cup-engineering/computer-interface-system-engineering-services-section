;;; gnopon-command-test.el --- Command-surface tests for GnoponEmacs -*- lexical-binding: t; -*-

;;; Code:

(require 'ert)
(require 'cl-lib)

(defvar recentf-list nil)

(defmacro gnopon-test-with-temp-project (&rest body)
  "Run BODY with `default-directory' bound to a temp Git project."
  (declare (indent 0))
  `(let ((default-directory (file-name-as-directory
                             (make-temp-file "gnopon-command-test-" t))))
     (make-directory (expand-file-name ".git/" default-directory) t)
     ,@body))

(ert-deftest gnopon-command-test-command-preview ()
  (gnopon-test-with-temp-project
    (let ((preview (gnopon/command-preview-text "pnpm install")))
      (should (string-match-p "Command Preview" preview))
      (should (string-match-p "risk: `write`" preview))
      (should (string-match-p "Inspect Git diff" preview)))))

(ert-deftest gnopon-command-test-project-command-matrix ()
  (gnopon-test-with-temp-project
    (with-temp-file (expand-file-name "package.json" default-directory)
      (insert "{\"scripts\":{\"check\":\"tsc --noEmit\",\"test\":\"node --test\",\"dev\":\"vite\"}}\n"))
    (with-temp-file (expand-file-name "Cargo.toml" default-directory)
      (insert "[package]\nname = \"demo\"\nversion = \"0.0.0\"\n"))
    (let* ((candidates (gnopon/project-command-candidates))
           (matrix (gnopon/project-command-matrix-text))
           (label (gnopon/project-command-candidate-label
                   (seq-find (lambda (candidate)
                               (string= (alist-get 'label candidate) "package:check"))
                             candidates)))
           captured)
      (should (seq-some (lambda (candidate)
                          (string= (alist-get 'command candidate) "cargo test"))
                        candidates))
      (should (seq-some (lambda (candidate)
                          (string= (alist-get 'command candidate) "npm run check"))
                        candidates))
      (should (string-match-p "Project Command Matrix" matrix))
      (should (string-match-p "cargo:test" matrix))
      (should (string-match-p "package:dev" matrix))
      (cl-letf (((symbol-function 'gnopon/compile-in-project)
                 (lambda (command) (setq captured command))))
        (gnopon/run-project-command-candidate label)
        (should (equal captured "npm run check"))))))

(ert-deftest gnopon-command-test-capability-audit ()
  (gnopon-test-with-temp-project
    (let ((audit (gnopon/capability-audit-text)))
      (should (string-match-p "GnoponEmacs Capability Audit" audit))
      (should (string-match-p "markdown-memory" audit))
      (should (string-match-p "agentic-programming" audit))
      (should (string-match-p "reproducibility" audit))
      (should (string-match-p "| Capability | Status | Requirement | Evidence Or Gap |" audit)))))

(ert-deftest gnopon-command-test-doctor-report ()
  (gnopon-test-with-temp-project
    (let ((report (gnopon/doctor-text)))
      (should (string-match-p "GnoponEmacs Doctor" report))
      (should (string-match-p "External Tools" report))
      (should (string-match-p "Emacs Package Closure" report))
      (should (string-match-p "command matrix" report))
      (should (string-match-p "AI calls are manual" report)))
    (let ((root default-directory)
          (path (gnopon/write-doctor-report)))
      (should (file-readable-p path))
      (should (string-prefix-p (expand-file-name "logs/doctor/" root) path))
      (with-temp-buffer
        (insert-file-contents path)
        (goto-char (point-min))
        (should (search-forward "GnoponEmacs Doctor" nil t))))))

(ert-deftest gnopon-command-test-performance-report ()
  (gnopon-test-with-temp-project
    (let ((report (gnopon/performance-report-text)))
      (should (string-match-p "GnoponEmacs Performance Report" report))
      (should (string-match-p "startup-seconds" report))
      (should (string-match-p "package-count" report))
      (should (string-match-p "loaded-gnopon-modules" report))
      (should (string-match-p "External Benchmark" report)))
    (let ((root default-directory)
          (path (gnopon/write-performance-report)))
      (should (file-readable-p path))
      (should (string-prefix-p (expand-file-name "logs/performance/" root) path))
      (with-temp-buffer
        (insert-file-contents path)
        (goto-char (point-min))
        (should (search-forward "Performance Report" nil t))))))

(ert-deftest gnopon-command-test-project-dashboard-text ()
  (gnopon-test-with-temp-project
    (with-temp-file (expand-file-name "README.md" default-directory)
      (insert "# Demo\n"))
    (with-temp-file (expand-file-name "TODO.md" default-directory)
      (insert "# TODO\n\n- [ ] ship dashboard\n"))
    (let ((dashboard (gnopon/project-dashboard-text)))
      (should (string-match-p "Project Cockpit" dashboard))
      (should (string-match-p "Project Memory" dashboard))
      (should (string-match-p "Tool Readiness" dashboard))
      (should (string-match-p "Command Paths" dashboard))
      (should (string-match-p "M-SPC" dashboard))
      (should (string-match-p "README.md" dashboard)))))

(ert-deftest gnopon-command-test-workspace-snapshot ()
  (gnopon-test-with-temp-project
    (let* ((root default-directory)
           (readme (expand-file-name "README.md" root))
           (plan (expand-file-name "PLAN.md" root))
           (notes-dir (expand-file-name "docs/notes/" root))
           (note (expand-file-name "day.md" notes-dir))
           readme-buffer
           plan-buffer)
      (make-directory notes-dir t)
      (with-temp-file readme
        (insert "# Demo\n"))
      (with-temp-file plan
        (insert "# PLAN\n"))
      (with-temp-file note
        (insert "# Day\n"))
      (setq readme-buffer (find-file-noselect readme))
      (setq plan-buffer (find-file-noselect plan))
      (with-current-buffer plan-buffer
        (goto-char (point-max))
        (insert "\n- [ ] keep context\n"))
      (let ((old-recentf-list recentf-list))
        (unwind-protect
            (progn
              (setq recentf-list (list note readme "/tmp/outside.md"))
              (let ((snapshot (gnopon/workspace-snapshot-text)))
                (should (string-match-p "Workspace Snapshot" snapshot))
                (should (string-match-p "README.md" snapshot))
                (should (string-match-p "PLAN.md" snapshot))
                (should (string-match-p "\\[!\\].*PLAN.md" snapshot))
                (should (string-match-p "docs/notes/day.md" snapshot))
                (should (string-match-p "agent handoff" snapshot)))
              (let ((path (gnopon/write-workspace-snapshot)))
                (should (file-readable-p path))
                (should (string-prefix-p (expand-file-name "logs/workspace/" root) path))
                (with-temp-buffer
                  (insert-file-contents path)
                  (goto-char (point-min))
                  (should (search-forward "Workspace Snapshot" nil t)))))
          (setq recentf-list old-recentf-list)
          (when (buffer-live-p plan-buffer)
            (with-current-buffer plan-buffer
              (set-buffer-modified-p nil)))
          (when (buffer-live-p readme-buffer)
            (kill-buffer readme-buffer))
          (when (buffer-live-p plan-buffer)
            (kill-buffer plan-buffer)))))))

(ert-deftest gnopon-command-test-markdown-link-graph-report ()
  (gnopon-test-with-temp-project
    (make-directory (expand-file-name "docs/" default-directory) t)
    (with-temp-file (expand-file-name "README.md" default-directory)
      (insert "# Demo\n\nSee [Spec](docs/spec.md), [[Guide]], [Missing](missing.md), and [Web](https://example.com).\n"))
    (with-temp-file (expand-file-name "Guide.md" default-directory)
      (insert "# Guide\n\n"))
    (with-temp-file (expand-file-name "docs/spec.md" default-directory)
      (insert "# Spec\n\nSee [README](../README.md).\n"))
    (with-temp-file (expand-file-name "docs/orphan.md" default-directory)
      (insert "# Orphan\n\n"))
    (let ((report (gnopon/markdown-link-graph-report-text)))
      (should (string-match-p "Markdown Link Graph" report))
      (should (string-match-p "present: `3`" report))
      (should (string-match-p "missing: `1`" report))
      (should (string-match-p "external: `1`" report))
      (should (string-match-p "README.md:3.*docs/spec.md" report))
      (should (string-match-p "README.md:3.*Guide.md" report))
      (should (string-match-p "missing.md" report))
      (should (string-match-p "docs/orphan.md" report)))))

(ert-deftest gnopon-command-test-github-dashboard-text ()
  (gnopon-test-with-temp-project
    (let ((dashboard (gnopon/github-dashboard-text)))
      (should (string-match-p "GitHub Cockpit" dashboard))
      (should (string-match-p "Local Review" dashboard))
      (should (string-match-p "GitHub Read Models" dashboard))
      (should (string-match-p "C-c g g h p" dashboard))
      (should (string-match-p "C-c g r B" dashboard)))))

(ert-deftest gnopon-command-test-task-parsing-and-counts ()
  (let* ((todo (gnopon/task-parse-rg-line "TODO.md:3:- [ ] ship cockpit"))
         (done (gnopon/task-parse-rg-line "TODO.md:4:- [x] write tests"))
         (canceled (gnopon/task-parse-rg-line "TODO.md:5:- [-] obsolete"))
         (counts (gnopon/task-counts (list todo done canceled))))
    (should (equal (alist-get 'file todo) "TODO.md"))
    (should (= (alist-get 'line todo) 3))
    (should (eq (alist-get 'state todo) 'todo))
    (should (= (alist-get 'todo counts) 1))
    (should (= (alist-get 'done counts) 1))
    (should (= (alist-get 'canceled counts) 1))
    (should (string-match-p "TODO.md:3" (gnopon/task-format-item todo)))))

(ert-deftest gnopon-command-test-capture-task ()
  (gnopon-test-with-temp-project
    (gnopon/capture-task "review generated patch")
    (let ((todo (expand-file-name "TODO.md" default-directory)))
      (should (file-readable-p todo))
      (with-temp-buffer
        (insert-file-contents todo)
        (should (search-forward "- [ ]" nil t))
        (goto-char (point-min))
        (should (search-forward "review generated patch" nil t))))))

(ert-deftest gnopon-command-test-agent-handoff ()
  (gnopon-test-with-temp-project
    (let ((root default-directory))
      (with-temp-file (expand-file-name "AGENTS.md" root)
        (insert "# AGENTS\n\n## Build And Test\n\n"))
      (with-temp-file (expand-file-name "TODO.md" root)
        (insert "# TODO\n\n- [ ] review handoff\n"))
      (let ((packet (gnopon/agent-handoff-text "Review agent work")))
        (should (string-match-p "Agent Handoff" packet))
        (should (string-match-p "Review agent work" packet))
        (should (string-match-p "Safety Invariants" packet))
        (should (string-match-p "Project Memory" packet))
        (should (string-match-p "todo: `1`" packet))
        (should (string-match-p "C-c g a s" packet)))
      (let ((path (gnopon/write-agent-handoff "Review agent work")))
        (should (file-readable-p path))
        (should (string-prefix-p (expand-file-name "logs/agent/" root) path))
        (with-temp-buffer
          (insert-file-contents path)
          (goto-char (point-min))
          (should (search-forward "Recommended Flow" nil t))
          (goto-char (point-min))
          (should (search-forward "Diff Stat" nil t)))))))

(ert-deftest gnopon-command-test-context-bundle-focus ()
  (gnopon-test-with-temp-project
    (let* ((root default-directory)
           (source (expand-file-name "src/service.rs" root))
           source-buffer)
      (make-directory (file-name-directory source) t)
      (with-temp-file source
        (insert "fn main() {\n")
        (insert "    let API_KEY=\"abc123\";\n")
        (insert "}\n"))
      (setq source-buffer (find-file-noselect source))
      (unwind-protect
          (with-current-buffer source-buffer
            (let ((bundle (gnopon/context-bundle "Focused Context")))
              (should (string-match-p "Focused Work Item" bundle))
              (should (string-match-p "- source: `src/service.rs`" bundle))
              (should (string-match-p "- scope: `buffer`" bundle))
              (should (string-match-p "API_KEY= \\[REDACTED\\]" bundle))
              (should-not (string-match-p "abc123" bundle))))
        (when (buffer-live-p source-buffer)
          (kill-buffer source-buffer))))))

(ert-deftest gnopon-command-test-api-note-and-status ()
  (gnopon-test-with-temp-project
    (let ((root default-directory))
      (gnopon/api-request-note "Health Check")
      (should (string-suffix-p "health-check.md" (or buffer-file-name "")))
      (should (string-match-p "## Request" (buffer-string)))
      (should (string-match-p "Curl log captured" (buffer-string)))
      (let* ((default-directory root)
             (status (with-temp-buffer
                       (let ((buffer (current-buffer)))
                         (cl-letf (((symbol-function 'pop-to-buffer) (lambda (&rest _args) nil))
                                   ((symbol-function 'get-buffer-create) (lambda (&rest _args) buffer)))
                           (gnopon/api-status)
                           (buffer-string))))))
        (should (string-match-p "API Status" status))
        (should (string-match-p "requests.http" status))))))

(ert-deftest gnopon-command-test-review-pr-body-file ()
  (gnopon-test-with-temp-project
    (let ((path (gnopon/write-pr-body-file nil)))
      (should (file-readable-p path))
      (should (string-prefix-p (expand-file-name "logs/review/" default-directory) path))
      (with-temp-buffer
        (insert-file-contents path)
        (should (search-forward "## Summary" nil t))
        (should (search-forward "## Tests" nil t))
        (should (search-forward "## Review Notes" nil t))))))

(ert-deftest gnopon-command-test-formal-bootstrap ()
  (gnopon-test-with-temp-project
    (let ((predication-dir (expand-file-name "docs/predications/" default-directory)))
      (make-directory predication-dir t)
      (with-temp-file (expand-file-name "20260617-agent-evidence.md" predication-dir)
        (insert (gnopon/predication-frontmatter-string
                 "agent" "keeps" "evidence" "present" "strict" "knowledge"))
        (insert "# agent / keeps / evidence\n"))
      (gnopon/formal-bootstrap)
      (dolist (file '("README.md" "schema.ttl" "predications.ttl" "proof-obligations.md"))
        (should (file-readable-p (expand-file-name (concat "docs/formal/" file)
                                                   default-directory))))
      (with-temp-buffer
        (insert-file-contents (expand-file-name "docs/formal/predications.ttl"
                                                default-directory))
        (should (search-forward "g:PredicationCell" nil t))
        (should (search-forward "g:present" nil t))))))

;;; gnopon-command-test.el ends here
