;;; gnopon-markdown.el --- Markdown project memory -*- lexical-binding: t; -*-

;;; Code:

(require 'gnopon-core)
(require 'gnopon-lib)
(require 'seq)

(defvar gnopon-context-files
  '("README.md" "SPEC.md" "PLAN.md" "TODO.md" "CHANGELOG.md"
    "AGENTS.md" "CLAUDE.md" "GEMINI.md" "docs/adr/README.md" "docs/rfc/README.md"
    "docs/predications/README.md")
  "Project memory files GnoponEmacs treats as first-class.")

(defvar gnopon-evidence-regimes
  '("strict" "scott-continuous" "transfinite-bounded" "aperiodic")
  "Validation and closure regimes for project memory.")

(defvar gnopon-evidence-sides
  '("truth" "knowledge" "conflict" "gap")
  "Paraconsistent evidence sides.")

(use-package markdown-mode
  :mode (("\\.md\\'" . gfm-mode)
         ("README\\.md\\'" . gfm-mode))
  :custom
  (markdown-command "pandoc")
  (markdown-fontify-code-blocks-natively t)
  (markdown-enable-wiki-links t))

(use-package markdown-toc
  :after markdown-mode)

(use-package yaml-mode
  :mode ("\\.ya?ml\\'" . yaml-mode))

(defun gnopon/open-context-file (file)
  "Open project context FILE, creating parent directories if needed."
  (interactive
   (list (completing-read "Context file: " gnopon-context-files nil nil nil nil "PLAN.md")))
  (let ((path (gnopon/project-file file)))
    (make-directory (file-name-directory path) t)
    (find-file path)
    (when (= (point-min) (point-max))
      (gnopon/insert-context-template file))))

(defun gnopon/bootstrap-project-memory ()
  "Create missing standard Markdown project-memory files."
  (interactive)
  (dolist (file '("README.md" "SPEC.md" "PLAN.md" "TODO.md" "CHANGELOG.md" "AGENTS.md"
                  "docs/predications/README.md"))
    (let ((path (gnopon/project-file file)))
      (unless (file-exists-p path)
        (make-directory (file-name-directory path) t)
        (with-temp-file path
          (gnopon/insert-context-template file)))))
  (message "Bootstrapped project memory in %s" (gnopon/project-root)))

(defun gnopon/sync-agent-context-files ()
  "Create CLAUDE.md and GEMINI.md from AGENTS.md with tool-specific headers."
  (interactive)
  (let* ((root (gnopon/project-root))
         (agents (expand-file-name "AGENTS.md" root)))
    (unless (file-readable-p agents)
      (user-error "AGENTS.md does not exist"))
    (dolist (file '("CLAUDE.md" "GEMINI.md"))
      (with-temp-file (expand-file-name file root)
        (insert "# " file "\n\n")
        (insert "This file is generated from `AGENTS.md` for tool-specific agent context. Edit `AGENTS.md` first, then resync.\n\n")
        (insert-file-contents agents))))
  (message "Synced CLAUDE.md and GEMINI.md from AGENTS.md"))

(defun gnopon/markdown-title-for-file (file)
  "Return a human title for context FILE."
  (file-name-base (directory-file-name file)))

(defun gnopon/insert-context-template (file)
  "Insert a project-memory template for FILE."
  (let ((title (gnopon/markdown-title-for-file file)))
    (cond
     ((string= file "AGENTS.md")
      (insert "# AGENTS.md\n\n## Project Contract\n\n## Build And Test\n\n## Review Rules\n\n## Agent Safety\n\n- Do not commit without human review.\n- Do not send secrets to external services.\n- Leave command logs and diffs as evidence.\n"))
     ((member file '("CLAUDE.md" "GEMINI.md"))
      (insert "# " file "\n\nThis file mirrors durable project context from `AGENTS.md` for tool-specific agents.\n\n## Project Context\n\n## Commands\n\n## Safety\n\n"))
     ((string= file "SPEC.md")
      (insert "# SPEC\n\n## Problem\n\n## Goals\n\n## Non-Goals\n\n## Interfaces\n\n## Acceptance Criteria\n\n"))
     ((string= file "PLAN.md")
      (insert "# PLAN\n\n## Current Objective\n\n## Milestones\n\n- [ ] \n\n## Risks\n\n## Evidence\n\n"))
     ((string= file "TODO.md")
      (insert "# TODO\n\n- [ ] \n"))
     ((string= file "CHANGELOG.md")
      (insert "# Changelog\n\n## Unreleased\n\n- \n"))
     ((string= file "docs/predications/README.md")
      (insert "# Predications\n\nEach file in this directory is a Markdown predication cell with YAML frontmatter, one cell per file.\n\n## Fields\n\n- `subject`\n- `predicate`\n- `object`\n- `value`\n- `evidence-regime`\n- `evidence-side`\n- `depends-on`\n"))
     (t
      (insert "# " title "\n\n")))))

(defun gnopon/insert-frontmatter (title)
  "Insert YAML frontmatter with TITLE."
  (interactive "sTitle: ")
  (insert (gnopon/markdown-frontmatter-string title)))

(defun gnopon/insert-task ()
  "Insert a GitHub-flavored Markdown task item."
  (interactive)
  (insert (format "- [ ] %s " (format-time-string "%Y-%m-%d"))))

(defun gnopon/toggle-task-at-point ()
  "Toggle the Markdown task state on the current line."
  (interactive)
  (let* ((bounds (bounds-of-thing-at-point 'line))
         (start (car bounds))
         (end (cdr bounds))
         (line (buffer-substring-no-properties start end)))
    (delete-region start end)
    (insert (gnopon/markdown-toggle-task-line line))))

(defun gnopon/insert-evidence-block (regime side)
  "Insert a Markdown evidence block labeled by REGIME and SIDE."
  (interactive
   (list (completing-read "Regime: " gnopon-evidence-regimes nil t)
         (completing-read "Side: " gnopon-evidence-sides nil t)))
  (insert (format "> [!NOTE]\n> evidence-regime: `%s`\n> evidence-side: `%s`\n> source: `%s`\n>\n> "
                  regime side (or (buffer-file-name) (buffer-name)))))

(defun gnopon/search-tasks ()
  "Search project Markdown task lists."
  (interactive)
  (consult-ripgrep (gnopon/project-root) "^- \\[[ xX-]\\] "))

(defun gnopon/search-backlinks ()
  "Search for Markdown links or wiki-style references to the current stem."
  (interactive)
  (let* ((stem (file-name-base (or (buffer-file-name) (read-string "Reference: "))))
         (pattern (format "\\[%s\\]|\\[\\[%s\\]\\]" (regexp-quote stem) (regexp-quote stem))))
    (consult-ripgrep (gnopon/project-root) pattern)))

(defun gnopon/search-project-memory ()
  "Search known Markdown project-memory files."
  (interactive)
  (consult-ripgrep (gnopon/project-root)
                   "README|SPEC|PLAN|TODO|CHANGELOG|AGENTS|CLAUDE|GEMINI|ADR|RFC"))

(defun gnopon/markdown-file-text (file)
  "Return the contents of Markdown FILE."
  (with-temp-buffer
    (insert-file-contents file)
    (buffer-string)))

(defun gnopon/markdown-project-files ()
  "Return project Markdown files that represent durable memory."
  (let* ((root (file-truename (gnopon/project-root)))
         (root-files (directory-files root t "\\.md\\'"))
         (docs-dir (expand-file-name "docs/" root))
         (docs-files (when (file-directory-p docs-dir)
                       (directory-files-recursively docs-dir "\\.md\\'")))
         (context-files (mapcar (lambda (file) (expand-file-name file root))
                                gnopon-context-files))
         (files (append root-files docs-files context-files)))
    (sort
     (seq-uniq
      (seq-filter (lambda (file)
                    (and (file-readable-p file)
                         (string-prefix-p root (file-truename file))
                         (not (string-match-p "/\\(\\.git\\|node_modules\\|logs\\|var\\)/"
                                              (file-truename file)))))
                  files)
      #'string=)
     #'string<)))

(defun gnopon/markdown-structure-issue (summary)
  "Return a structural issue label for Markdown SUMMARY, or nil."
  (let ((h1-count (alist-get 'h1 summary)))
    (cond
     ((zerop h1-count) "missing H1")
     ((> h1-count 1) "multiple H1")
     (t nil))))

(defun gnopon/markdown-structure-file-section (root file)
  "Return a Markdown structure section for FILE under ROOT."
  (let* ((relative (file-relative-name file root))
         (text (gnopon/markdown-file-text file))
         (summary (gnopon/markdown-structure-summary text))
         (headings (gnopon/markdown-heading-entries text))
         (links (gnopon/markdown-link-entries text))
         (tasks (gnopon/markdown-task-entries text))
         (issue (gnopon/markdown-structure-issue summary)))
    (concat "## `" relative "`\n\n"
            "- headings: `" (number-to-string (alist-get 'headings summary)) "`\n"
            "- h1: `" (number-to-string (alist-get 'h1 summary)) "`"
            (if issue (concat " - " issue) "")
            "\n"
            "- links: `" (number-to-string (alist-get 'links summary)) "`\n"
            "- tasks: `" (number-to-string (alist-get 'tasks summary)) "`\n\n"
            "### Headings\n\n"
            (if headings
                (mapconcat (lambda (entry)
                             (format "- `%s` %s %s\n"
                                     (number-to-string (alist-get 'line entry))
                                     (make-string (alist-get 'level entry) ?#)
                                     (alist-get 'title entry)))
                           headings
                           "")
              "- none\n")
            "\n### Links\n\n"
            (if links
                (mapconcat (lambda (entry)
                             (format "- `%s` %s -> `%s`\n"
                                     (number-to-string (alist-get 'line entry))
                                     (alist-get 'label entry)
                                     (alist-get 'target entry)))
                           links
                           "")
              "- none\n")
            "\n### Task States\n\n"
            (if tasks
                (let ((todo 0)
                      (done 0)
                      (canceled 0))
                  (dolist (task tasks)
                    (pcase (alist-get 'state task)
                      ('todo (setq todo (1+ todo)))
                      ('done (setq done (1+ done)))
                      ('canceled (setq canceled (1+ canceled)))))
                  (format "- todo: `%s`\n- done: `%s`\n- canceled: `%s`\n"
                          todo done canceled))
              "- none\n")
            "\n### Tasks\n\n"
            (if tasks
                (mapconcat (lambda (entry)
                             (format "- `%s` %s\n"
                                     (number-to-string (alist-get 'line entry))
                                     (alist-get 'text entry)))
                           tasks
                           "")
              "- none\n")
            "\n")))

(defun gnopon/markdown-structure-report-text ()
  "Return a Markdown structure report for project memory files."
  (let* ((root (file-truename (gnopon/project-root)))
         (files (gnopon/markdown-project-files)))
    (concat "# Markdown Structure Report\n\n"
            "- project: `" root "`\n"
            "- files: `" (number-to-string (length files)) "`\n\n"
            "## File Summary\n\n"
            (if files
                (mapconcat
                 (lambda (file)
                   (let* ((relative (file-relative-name file root))
                          (summary (gnopon/markdown-structure-summary
                                    (gnopon/markdown-file-text file)))
                          (issue (gnopon/markdown-structure-issue summary)))
                     (format "- %s `%s` - headings `%s`, links `%s`, tasks `%s`%s\n"
                             (if issue "[ ]" "[x]")
                             relative
                             (alist-get 'headings summary)
                             (alist-get 'links summary)
                             (alist-get 'tasks summary)
                             (if issue (concat ", " issue) ""))))
                 files
                 "")
              "- none\n")
            "\n# Files\n\n"
            (mapconcat (lambda (file)
                         (gnopon/markdown-structure-file-section root file))
                       files
                       "\n"))))

(defun gnopon/markdown-structure-report ()
  "Open a generated structure report for project Markdown memory."
  (interactive)
  (let ((buffer (get-buffer-create "*markdown-structure*")))
    (with-current-buffer buffer
      (read-only-mode -1)
      (erase-buffer)
      (insert (gnopon/markdown-structure-report-text))
      (gnopon/markdown-buffer-mode)
      (goto-char (point-min))
      (read-only-mode 1))
    (pop-to-buffer buffer)))

(defun gnopon/markdown-link-external-p (target)
  "Return non-nil when TARGET is not a project-local Markdown link."
  (or (string-match-p "\\`[a-zA-Z][a-zA-Z0-9+.-]*:" target)
      (string-prefix-p "//" target)))

(defun gnopon/markdown-strip-link-fragment (target)
  "Return TARGET without URL query or fragment suffix."
  (car (split-string target "[#?]" t)))

(defun gnopon/markdown-normalize-link-target (root source-relative entry known-files)
  "Return a normalized link edge target for ENTRY.
ROOT is the project root, SOURCE-RELATIVE is the source Markdown file, and
KNOWN-FILES is the list of project Markdown files relative to ROOT."
  (let* ((raw-target (string-trim (alist-get 'target entry)))
         (type (alist-get 'type entry))
         (source-dir (file-name-directory source-relative))
         (target (gnopon/markdown-strip-link-fragment raw-target)))
    (cond
     ((string-empty-p raw-target)
      `((status . missing) (target . "") (raw . ,raw-target)))
     ((string-prefix-p "#" raw-target)
      `((status . anchor) (target . ,source-relative) (raw . ,raw-target)))
     ((gnopon/markdown-link-external-p raw-target)
      `((status . external) (target . ,raw-target) (raw . ,raw-target)))
     ((string-empty-p target)
      `((status . anchor) (target . ,source-relative) (raw . ,raw-target)))
     (t
      (let* ((base (cond
                    ((eq type 'wiki) target)
                    ((file-name-absolute-p target)
                     (string-remove-prefix "/" target))
                    (t (concat (or source-dir "") target))))
             (base-relative (file-relative-name (expand-file-name base root) root))
             (candidates (seq-uniq
                          (delq nil
                                (list base-relative
                                      (unless (string-match-p "\\.md\\'" base-relative)
                                        (concat base-relative ".md"))
                                      (concat (file-name-as-directory base-relative) "README.md")
                                      (when (eq type 'wiki)
                                        (concat target ".md"))
                                      (when (eq type 'wiki)
                                        (concat (file-name-as-directory target) "README.md"))))
                          #'string=))
             (match (seq-find (lambda (candidate)
                                (member candidate known-files))
                              candidates)))
        `((status . ,(if match 'present 'missing))
          (target . ,(or match (car candidates)))
          (raw . ,raw-target)))))))

(defun gnopon/markdown-link-graph-edges ()
  "Return normalized Markdown link graph edges for project memory."
  (let* ((root (file-truename (gnopon/project-root)))
         (files (gnopon/markdown-project-files))
         (known (mapcar (lambda (file) (file-relative-name file root)) files))
         edges)
    (dolist (file files)
      (let* ((relative (file-relative-name file root))
             (text (gnopon/markdown-file-text file)))
        (dolist (entry (gnopon/markdown-link-entries text))
          (let ((target (gnopon/markdown-normalize-link-target
                         root relative entry known)))
            (push `((from . ,relative)
                    (line . ,(alist-get 'line entry))
                    (label . ,(alist-get 'label entry))
                    (type . ,(alist-get 'type entry))
                    (to . ,(alist-get 'target target))
                    (raw . ,(alist-get 'raw target))
                    (status . ,(alist-get 'status target)))
                  edges)))))
    (nreverse edges)))

(defun gnopon/markdown-link-graph-counts (files edges)
  "Return incoming/outgoing counts for FILES from graph EDGES."
  (let ((counts (mapcar (lambda (file)
                          `(,file . ((incoming . 0) (outgoing . 0))))
                        files)))
    (dolist (edge edges)
      (when (eq (alist-get 'status edge) 'present)
        (when-let ((from (assoc (alist-get 'from edge) counts)))
          (let ((cell (assoc 'outgoing (cdr from))))
            (setcdr cell (1+ (cdr cell)))))
        (when-let ((to (assoc (alist-get 'to edge) counts)))
          (let ((cell (assoc 'incoming (cdr to))))
            (setcdr cell (1+ (cdr cell)))))))
    counts))

(defun gnopon/markdown-link-graph-report-text ()
  "Return a Markdown report of project-memory Markdown links."
  (let* ((root (file-truename (gnopon/project-root)))
         (files (mapcar (lambda (file)
                          (file-relative-name file root))
                        (gnopon/markdown-project-files)))
         (edges (gnopon/markdown-link-graph-edges))
         (counts (gnopon/markdown-link-graph-counts files edges))
         (present (seq-filter (lambda (edge) (eq (alist-get 'status edge) 'present)) edges))
         (missing (seq-filter (lambda (edge) (eq (alist-get 'status edge) 'missing)) edges))
         (external (seq-filter (lambda (edge) (eq (alist-get 'status edge) 'external)) edges))
         (orphans (seq-filter (lambda (row)
                                (let ((data (cdr row)))
                                  (and (zerop (alist-get 'incoming data))
                                       (not (string= (car row) "README.md")))))
                              counts)))
    (concat "# Markdown Link Graph\n\n"
            "- project: `" root "`\n"
            "- files: `" (number-to-string (length files)) "`\n"
            "- links: `" (number-to-string (length edges)) "`\n"
            "- present: `" (number-to-string (length present)) "`\n"
            "- missing: `" (number-to-string (length missing)) "`\n"
            "- external: `" (number-to-string (length external)) "`\n"
            "- orphans: `" (number-to-string (length orphans)) "`\n\n"
            "## Files\n\n"
            (if counts
                (mapconcat
                 (lambda (row)
                   (let ((data (cdr row)))
                     (format "- `%s` - incoming `%s`, outgoing `%s`\n"
                             (car row)
                             (alist-get 'incoming data)
                             (alist-get 'outgoing data))))
                 counts
                 "")
              "- none\n")
            "\n## Present Links\n\n"
            (if present
                (mapconcat
                 (lambda (edge)
                   (format "- `%s:%s` -> `%s` (%s)\n"
                           (alist-get 'from edge)
                           (alist-get 'line edge)
                           (alist-get 'to edge)
                           (alist-get 'label edge)))
                 present
                 "")
              "- none\n")
            "\n## Missing Links\n\n"
            (if missing
                (mapconcat
                 (lambda (edge)
                   (format "- `%s:%s` -> `%s` from `%s`\n"
                           (alist-get 'from edge)
                           (alist-get 'line edge)
                           (alist-get 'to edge)
                           (alist-get 'raw edge)))
                 missing
                 "")
              "- none\n")
            "\n## External Links\n\n"
            (if external
                (mapconcat
                 (lambda (edge)
                   (format "- `%s:%s` -> `%s`\n"
                           (alist-get 'from edge)
                           (alist-get 'line edge)
                           (alist-get 'raw edge)))
                 external
                 "")
              "- none\n")
            "\n## Orphans\n\n"
            (if orphans
                (mapconcat (lambda (row)
                             (format "- `%s`\n" (car row)))
                           orphans
                           "")
              "- none\n"))))

(defun gnopon/markdown-link-graph-report ()
  "Open a generated link graph report for project Markdown memory."
  (interactive)
  (let ((buffer (get-buffer-create "*markdown-link-graph*")))
    (with-current-buffer buffer
      (read-only-mode -1)
      (erase-buffer)
      (insert (gnopon/markdown-link-graph-report-text))
      (gnopon/markdown-buffer-mode)
      (goto-char (point-min))
      (read-only-mode 1))
    (pop-to-buffer buffer)))

(defun gnopon/project-memory-index ()
  "Open a generated index of project memory files."
  (interactive)
  (let* ((root (file-truename (gnopon/project-root)))
         (buffer (get-buffer-create (format "*memory:%s*" (file-name-nondirectory (directory-file-name root))))))
    (with-current-buffer buffer
      (read-only-mode -1)
      (erase-buffer)
      (insert "# Project Memory\n\n")
      (dolist (file gnopon-context-files)
        (let ((path (expand-file-name file root)))
          (insert (if (file-exists-p path) "- [x] " "- [ ] ")
                  "`" file "`\n")))
      (insert "\n## Open Tasks\n\n```text\n")
      (insert (condition-case err
                  (string-join (process-lines "rg" "-n" "^- \\[[ xX-]\\]" root) "\n")
                (error (format "task scan unavailable: %s" (error-message-string err)))))
      (insert "\n```\n")
      (gnopon/markdown-buffer-mode)
      (goto-char (point-min))
      (read-only-mode 1))
    (pop-to-buffer buffer)))

(defun gnopon/validate-project-memory ()
  "Check project memory for known evidence labels and task markers."
  (interactive)
  (let ((buffer (get-buffer-create "*memory-validation*"))
        (root (gnopon/project-root)))
    (with-current-buffer buffer
      (read-only-mode -1)
      (erase-buffer)
      (insert "# Project Memory Validation\n\n")
      (insert "## Evidence Labels\n\n")
      (insert "- regimes: `" (string-join gnopon-evidence-regimes "`, `") "`\n")
      (insert "- sides: `" (string-join gnopon-evidence-sides "`, `") "`\n\n")
      (insert "## Evidence Blocks\n\n```text\n")
      (insert (condition-case err
                  (string-join (process-lines "rg" "-n" "evidence-(regime|side):" root) "\n")
                (error (format "evidence scan unavailable: %s" (error-message-string err)))))
      (insert "\n```\n\n## Tasks\n\n```text\n")
      (insert (condition-case err
                  (string-join (process-lines "rg" "-n" "^- \\[[ xX-]\\]" root) "\n")
                (error (format "task scan unavailable: %s" (error-message-string err)))))
      (insert "\n```\n")
      (gnopon/markdown-buffer-mode)
      (goto-char (point-min))
      (read-only-mode 1))
    (pop-to-buffer buffer)))

(defun gnopon/create-adr (title)
  "Create an ADR Markdown file for TITLE."
  (interactive "sADR title: ")
  (let* ((slug (gnopon/markdown-slugify title))
         (dir (gnopon/project-file "docs/adr/"))
         (path (expand-file-name (format "%s-%s.md" (format-time-string "%Y%m%d") slug) dir)))
    (make-directory dir t)
    (find-file path)
    (when (= (point-min) (point-max))
      (gnopon/insert-frontmatter title)
      (insert "# " title "\n\n## Status\n\nProposed\n\n## Context\n\n## Decision\n\n## Consequences\n"))))

(defun gnopon/create-rfc (title)
  "Create an RFC Markdown file for TITLE."
  (interactive "sRFC title: ")
  (let* ((slug (gnopon/markdown-slugify title))
         (dir (gnopon/project-file "docs/rfc/"))
         (path (expand-file-name (format "%s.md" slug) dir)))
    (make-directory dir t)
    (find-file path)
    (when (= (point-min) (point-max))
      (gnopon/insert-frontmatter title)
      (insert "# " title "\n\n## Summary\n\n## Goals\n\n## Non-Goals\n\n## Design\n\n## Rollout\n"))))

(define-key gnopon-map (kbd "m o") #'gnopon/open-context-file)
(define-key gnopon-map (kbd "m f") #'gnopon/insert-frontmatter)
(define-key gnopon-map (kbd "m n") #'gnopon/insert-task)
(define-key gnopon-map (kbd "m N") #'gnopon/toggle-task-at-point)
(define-key gnopon-map (kbd "m e") #'gnopon/insert-evidence-block)
(define-key gnopon-map (kbd "m s") #'gnopon/search-tasks)
(define-key gnopon-map (kbd "m b") #'gnopon/search-backlinks)
(define-key gnopon-map (kbd "m i") #'gnopon/project-memory-index)
(define-key gnopon-map (kbd "m g") #'gnopon/markdown-link-graph-report)
(define-key gnopon-map (kbd "m u") #'gnopon/markdown-structure-report)
(define-key gnopon-map (kbd "m M") #'gnopon/search-project-memory)
(define-key gnopon-map (kbd "m B") #'gnopon/bootstrap-project-memory)
(define-key gnopon-map (kbd "m S") #'gnopon/sync-agent-context-files)
(define-key gnopon-map (kbd "m v") #'gnopon/validate-project-memory)
(define-key gnopon-map (kbd "m a") #'gnopon/create-adr)
(define-key gnopon-map (kbd "m r") #'gnopon/create-rfc)

(provide 'gnopon-markdown)
;;; gnopon-markdown.el ends here
