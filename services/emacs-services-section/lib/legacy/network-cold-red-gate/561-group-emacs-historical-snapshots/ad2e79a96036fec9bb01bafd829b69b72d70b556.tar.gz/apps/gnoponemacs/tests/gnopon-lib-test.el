;;; gnopon-lib-test.el --- Tests for pure GnoponEmacs helpers -*- lexical-binding: t; -*-

;;; Code:

(require 'ert)
(require 'gnopon-lib)

(ert-deftest gnopon-test-markdown-slugify ()
  (should (equal (gnopon/markdown-slugify "Agent Session: Fix API!") "agent-session-fix-api"))
  (should (equal (gnopon/markdown-slugify "  Rust/Node Cockpit  ") "rust-node-cockpit"))
  (should (equal (gnopon/markdown-slugify "---Already Sluggy---") "already-sluggy")))

(ert-deftest gnopon-test-frontmatter-string ()
  (should (string-match-p (regexp-quote "title: \"A \\\"quoted\\\" title\"")
                          (gnopon/markdown-frontmatter-string "A \"quoted\" title" "active" "2026-06-17" '("agent"))))
  (should (string-match-p "tags: \\[\"agent\", \"session\"\\]"
                          (gnopon/markdown-frontmatter-string "T" "active" "2026-06-17" '("agent" "session")))))

(ert-deftest gnopon-test-yaml-and-turtle-helpers ()
  (should (equal (gnopon/yaml-scalar-unquote "\"quoted value\"") "quoted value"))
  (should (equal (gnopon/yaml-scalar-unquote "plain") "plain"))
  (should (equal (gnopon/turtle-local-name "123 Value!") "n_123_value"))
  (should (equal (gnopon/turtle-string "a \"quote\"\nnext")
                 "\"a \\\"quote\\\"\\nnext\"")))

(ert-deftest gnopon-test-frontmatter-parse-and-set ()
  (let ((text "---\ntitle: \"Demo\"\nstatus: active\n---\n\n# Body\n"))
    (should (equal (alist-get 'status (gnopon/markdown-frontmatter-alist text)) "active"))
    (should (string-match-p "status: done"
                            (gnopon/markdown-frontmatter-set-field text 'status "done")))
    (should (string-match-p "evidence-side: knowledge"
                            (gnopon/markdown-frontmatter-set-field text "evidence-side" "knowledge"))))
  (should (string-prefix-p "---\nstatus: draft\n---"
                           (gnopon/markdown-frontmatter-set-field "# Body\n" 'status "draft"))))

(ert-deftest gnopon-test-predication-frontmatter ()
  (let ((text (gnopon/predication-frontmatter-string
               "work item" "has-state" "reviewed" "both" "strict" "conflict")))
    (should (equal (gnopon/predication-cell-title "work item" "has-state" "reviewed")
                   "work item / has-state / reviewed"))
    (should (string-match-p "type: predication-cell" text))
    (should (string-match-p "subject: \"work item\"" text))
    (should (string-match-p "value: both" text))
    (should (string-match-p "evidence-side: conflict" text))))

(ert-deftest gnopon-test-task-state-and-toggle ()
  (should (eq (gnopon/markdown-task-state "- [ ] write tests") 'todo))
  (should (eq (gnopon/markdown-task-state "- [x] write tests") 'done))
  (should (eq (gnopon/markdown-task-state "- [-] canceled") 'canceled))
  (should-not (gnopon/markdown-task-state "not a task"))
  (should (equal (gnopon/markdown-toggle-task-line "- [ ] write tests") "- [x] write tests"))
  (should (equal (gnopon/markdown-toggle-task-line "- [x] write tests") "- [ ] write tests"))
  (should (equal (gnopon/markdown-toggle-task-line "- [-] canceled") "- [-] canceled"))
  (should (equal (gnopon/markdown-toggle-task-line "not a task") "not a task")))

(ert-deftest gnopon-test-safe-command-risk ()
  (should (eq (gnopon/safe-command-risk "cargo test") 'low))
  (should (eq (gnopon/safe-command-risk "pnpm install") 'write))
  (should (eq (gnopon/safe-command-risk "curl https://example.com") 'network))
  (should (eq (gnopon/safe-command-risk "rm -rf /tmp/x") 'dangerous))
  (should (eq (gnopon/safe-command-risk "echo ok && rm file") 'dangerous)))

(ert-deftest gnopon-test-redaction-and-truncation ()
  (should (equal (gnopon/redact-secret-line "API_KEY=abc123") "API_KEY= [REDACTED]"))
  (should (equal (gnopon/redact-secret-line "Authorization Bearer abc123") "Authorization [REDACTED]"))
  (should (string-match-p "\\[REDACTED\\]" (gnopon/redact-secrets "ok\npassword: hunter2\n")))
  (should (equal (gnopon/truncate-text "short" 20) "short"))
  (should (string-match-p "truncated by GnoponEmacs" (gnopon/truncate-text "abcdef" 3))))

(ert-deftest gnopon-test-upsert-section ()
  (should (equal (gnopon/markdown-upsert-section "# Doc\n\n## Tests\n\nold\n\n## Notes\n\nn\n"
                                                 "## Tests"
                                                 "new\n")
                 "# Doc\n\n## Tests\n\nnew\n\n## Notes\n\nn\n"))
  (should (string-match-p "## Added\n\nbody\n"
                          (gnopon/markdown-upsert-section "# Doc\n" "## Added" "body"))))

(ert-deftest gnopon-test-markdown-structure-parsers ()
  (let* ((text "# Title\n\nSee [Plan](PLAN.md), ![alt](img.png), and [[Note|label]].\n\n## Tasks ##\n\n- [ ] open\n- [x] done\n")
         (headings (gnopon/markdown-heading-entries text))
         (links (gnopon/markdown-link-entries text))
         (tasks (gnopon/markdown-task-entries text))
         (summary (gnopon/markdown-structure-summary text)))
    (should (= (length headings) 2))
    (should (equal (alist-get 'title (car headings)) "Title"))
    (should (equal (alist-get 'title (cadr headings)) "Tasks"))
    (should (equal (alist-get 'slug (cadr headings)) "tasks"))
    (should (= (length links) 2))
    (should (equal (alist-get 'target (car links)) "PLAN.md"))
    (should (equal (alist-get 'type (cadr links)) 'wiki))
    (should (equal (alist-get 'label (cadr links)) "label"))
    (should (= (length tasks) 2))
    (should (eq (alist-get 'state (car tasks)) 'todo))
    (should (eq (alist-get 'state (cadr tasks)) 'done))
    (should (= (alist-get 'h1 summary) 1))
    (should (= (alist-get 'links summary) 2))
    (should (= (alist-get 'tasks summary) 2))))

;;; gnopon-lib-test.el ends here
