;;; gnopon-agents.el --- Explicit agentic programming workflows -*- lexical-binding: t; -*-

;;; Code:

(require 'gnopon-core)
(require 'gnopon-markdown)
(require 'gnopon-lib)
(require 'gnopon-context)

(defun gnopon/process-lines-safe (&rest args)
  "Run ARGS with `process-lines', returning output or an error string."
  (condition-case err
      (string-join (apply #'process-lines args) "\n")
    (error (format "unavailable: %s" (error-message-string err)))))

(defun gnopon/git-status-short ()
  "Return short Git status for the current project."
  (gnopon/process-lines-safe "git" "-C" (gnopon/project-root) "status" "--short"))

(defun gnopon/git-diff-stat ()
  "Return Git diff stat for the current project."
  (gnopon/process-lines-safe "git" "-C" (gnopon/project-root) "diff" "--stat"))

(defun gnopon/git-diff ()
  "Return unstaged Git diff for the current project."
  (gnopon/process-lines-safe "git" "-C" (gnopon/project-root) "diff"))

(defun gnopon/agent-context ()
  "Copy a Markdown agent context bundle to the kill ring."
  (interactive)
  (gnopon/copy-context-bundle))

(defun gnopon/agent-shell ()
  "Open a project-scoped comint buffer running `gnopon-agent-command'."
  (interactive)
  (let* ((default-directory (gnopon/project-root))
         (parts (split-string-shell-command gnopon-agent-command))
         (program (car parts))
         (args (cdr parts))
         (buffer (get-buffer-create (format "*agent:%s*" (file-name-nondirectory (directory-file-name default-directory))))))
    (unless program
      (user-error "No agent command configured"))
    (apply #'make-comint-in-buffer "agent" buffer program nil args)
    (pop-to-buffer buffer)))

(defun gnopon/review-agent-diff ()
  "Review current project changes after an agent run."
  (interactive)
  (if (fboundp 'magit-status)
      (magit-status (gnopon/project-root))
    (let ((buffer (get-buffer-create "*agent-diff*")))
      (with-current-buffer buffer
        (erase-buffer)
        (insert (gnopon/git-diff))
        (diff-mode))
      (pop-to-buffer buffer))))

(defun gnopon/agent-log-path ()
  "Return a timestamped project-local agent log path."
  (let ((dir (gnopon/project-file "logs/agent/")))
    (make-directory dir t)
    (expand-file-name (format "%s.md" (format-time-string "%Y%m%d-%H%M%S")) dir)))

(defun gnopon/agent-session-dir ()
  "Return the project-local agent session directory."
  (let ((dir (gnopon/project-file "logs/agent/")))
    (make-directory dir t)
    dir))

(defun gnopon/agent-session-path (title)
  "Return a project-local agent session path for TITLE."
  (expand-file-name
   (format "%s-%s.md" (format-time-string "%Y%m%d-%H%M%S") (gnopon/markdown-slugify title))
   (gnopon/agent-session-dir)))

(defun gnopon/start-agent-session (title)
  "Create a Markdown session record for an agent task TITLE."
  (interactive "sAgent session title: ")
  (let ((path (gnopon/agent-session-path title)))
    (find-file path)
    (insert (gnopon/markdown-frontmatter-string title "active" nil '("agent" "session")))
    (insert "# " title "\n\n")
    (insert "## Context\n\n")
    (insert "```text\n" (gnopon/git-status-short) "\n```\n\n")
    (insert "## Prompt\n\n\n## Transcript Notes\n\n\n## Commands\n\n\n## Diff Review\n\n\n## Tests\n\n\n## Completion\n\n- [ ] Diff reviewed\n- [ ] Tests captured\n- [ ] Human accepted changes\n")))

(defun gnopon/agent-session-index ()
  "Open an index of project-local agent session records."
  (interactive)
  (let ((buffer (get-buffer-create "*agent-sessions*"))
        (dir (gnopon/agent-session-dir)))
    (with-current-buffer buffer
      (read-only-mode -1)
      (erase-buffer)
      (insert "# Agent Sessions\n\n")
      (dolist (file (directory-files dir nil "\\.md\\'"))
        (insert "- `" file "`\n"))
      (gnopon/markdown-buffer-mode)
      (goto-char (point-min))
      (read-only-mode 1))
    (pop-to-buffer buffer)))

(defun gnopon/agent-recent-session-list ()
  "Return recent project-local agent session filenames."
  (let ((dir (gnopon/agent-session-dir)))
    (when (file-directory-p dir)
      (last (sort (directory-files dir nil "\\.md\\'") #'string<) 8))))

(defun gnopon/agent-handoff-memory-section (root)
  "Return a project memory readiness section for ROOT."
  (concat
   "## Project Memory\n\n"
   (mapconcat (lambda (file)
                (let ((path (expand-file-name file root)))
                  (format "- %s `%s`\n"
                          (if (file-readable-p path) "[x]" "[ ]")
                          file)))
              gnopon-context-files
              "")
   "\n"))

(defun gnopon/agent-handoff-task-section ()
  "Return task counts for an agent handoff packet."
  (if (and (fboundp 'gnopon/task-items)
           (fboundp 'gnopon/task-counts))
      (let* ((tasks (gnopon/task-items))
             (counts (gnopon/task-counts tasks)))
        (format (concat "## Tasks\n\n"
                        "- todo: `%s`\n"
                        "- done: `%s`\n"
                        "- canceled: `%s`\n"
                        "- task cockpit: `C-c g m t`\n\n")
                (alist-get 'todo counts)
                (alist-get 'done counts)
                (alist-get 'canceled counts)))
    "## Tasks\n\n- task cockpit unavailable until task module loads\n\n"))

(defun gnopon/agent-handoff-session-section ()
  "Return recent agent sessions for a handoff packet."
  (let ((sessions (gnopon/agent-recent-session-list)))
    (concat "## Recent Agent Sessions\n\n"
            (if sessions
                (mapconcat (lambda (file) (format "- `%s`\n" file))
                           sessions
                           "")
              "- none\n")
            "\n")))

(defun gnopon/agent-handoff-text (&optional title)
  "Return a local, redacted Markdown handoff packet for agent work.
Optional TITLE names the handoff objective."
  (let ((root (file-truename (gnopon/project-root))))
    (concat "# Agent Handoff\n\n"
            "- title: `" (or title "Agent work") "`\n"
            "- project: `" root "`\n"
            "- created: `" (format-time-string "%Y-%m-%d %H:%M:%S") "`\n"
            "- agent-command: `" gnopon-agent-command "`\n"
            "- agent-command-risk: `" (format "%s" (gnopon/safe-command-risk gnopon-agent-command)) "`\n\n"
            "## Safety Invariants\n\n"
            "- Copy or write redacted context before invoking an agent.\n"
            "- Do not send secrets or unreviewed local-only files.\n"
            "- Do not run shell commands, commit, push, or open PRs without explicit human confirmation.\n"
            "- Treat conflicts, gaps, and failing tests as evidence to preserve.\n\n"
            "## Git State\n\n```text\n"
            (gnopon/redact-secrets (gnopon/git-status-short))
            "\n```\n\n## Diff Stat\n\n```text\n"
            (gnopon/redact-secrets (gnopon/git-diff-stat))
            "\n```\n\n"
            (gnopon/agent-handoff-memory-section root)
            (gnopon/agent-handoff-task-section)
            (gnopon/agent-handoff-session-section)
            "## Recommended Flow\n\n"
            "1. Open project dashboard: `C-c g w d`.\n"
            "2. Inspect memory graph: `C-c g m g`.\n"
            "3. Copy redacted context: `C-c g a C`.\n"
            "4. Start a session record: `C-c g a n`.\n"
            "5. Launch agent shell only when ready: `C-c g a s`.\n"
            "6. Review diff: `C-c g a r`.\n"
            "7. Capture tests/logs: `C-c g a l`.\n"
            "8. Prepare PR handoff: `C-c g r`.\n\n")))

(defun gnopon/open-agent-handoff (title)
  "Open a read-only agent handoff packet for TITLE."
  (interactive "sHandoff title: ")
  (let ((buffer (get-buffer-create "*agent-handoff*")))
    (with-current-buffer buffer
      (read-only-mode -1)
      (erase-buffer)
      (insert (gnopon/agent-handoff-text title))
      (gnopon/markdown-buffer-mode)
      (goto-char (point-min))
      (read-only-mode 1))
    (pop-to-buffer buffer)))

(defun gnopon/agent-handoff-path (title)
  "Return a project-local handoff packet path for TITLE."
  (let ((dir (gnopon/project-file "logs/agent/")))
    (make-directory dir t)
    (expand-file-name
     (format "%s-handoff-%s.md"
             (format-time-string "%Y%m%d-%H%M%S")
             (gnopon/markdown-slugify title))
     dir)))

(defun gnopon/write-agent-handoff (title)
  "Write an agent handoff packet for TITLE under `logs/agent/'."
  (interactive "sHandoff title: ")
  (let ((path (gnopon/agent-handoff-path title)))
    (with-temp-file path
      (insert (gnopon/agent-handoff-text title)))
    (find-file path)
    path))

(defun gnopon/copy-agent-handoff (title)
  "Copy an agent handoff packet for TITLE to the kill ring."
  (interactive "sHandoff title: ")
  (kill-new (gnopon/agent-handoff-text title))
  (message "Copied agent handoff for %s" (gnopon/project-root)))

(defun gnopon/search-agent-sessions ()
  "Search project-local agent session records."
  (interactive)
  (consult-ripgrep (gnopon/agent-session-dir) "TODO\\|Prompt\\|Completion\\|status: active\\|evidence"))

(defun gnopon/close-agent-session ()
  "Mark the current agent session Markdown file as done."
  (interactive)
  (unless (and buffer-file-name
               (string-match-p "/logs/agent/.*\\.md\\'" buffer-file-name))
    (user-error "Current buffer is not an agent session file"))
  (let ((text (buffer-substring-no-properties (point-min) (point-max))))
    (erase-buffer)
    (insert (gnopon/markdown-frontmatter-set-field text 'status "done"))
    (save-buffer)))

(defun gnopon/capture-command-log (command)
  "Run COMMAND after confirmation and capture output in a Markdown log."
  (interactive "sCommand to run and log: ")
  (let ((risk (gnopon/safe-command-risk command)))
    (when (eq risk 'dangerous)
      (user-error "Refusing dangerous shell command: %s" command))
    (unless (yes-or-no-p (format "Run and log `%s` (%s risk) in %s? "
                                 command risk (gnopon/project-root)))
      (user-error "Canceled")))
  (let* ((default-directory (gnopon/project-root))
         (path (gnopon/agent-log-path))
         (buffer (get-buffer-create "*agent-command-log*"))
         (exit-code nil))
    (with-current-buffer buffer
      (erase-buffer)
      (insert "# Command Log\n\n")
      (insert "- command: `" command "`\n")
      (insert "- project: `" default-directory "`\n")
      (insert "- created: " (format-time-string "%Y-%m-%d %H:%M:%S") "\n\n")
      (insert "## Output\n\n```text\n")
      (setq exit-code (call-process shell-file-name nil buffer t shell-command-switch command))
      (insert "\n```\n\n")
      (insert (format "exit-code: `%s`\n" exit-code))
      (write-region (point-min) (point-max) path))
    (find-file path)))

(defun gnopon/insert-agent-task ()
  "Insert a Markdown scaffold for auditable agent work."
  (interactive)
  (insert (format "## Agent Task - %s\n\n- [ ] Objective: \n- [ ] Context copied\n- [ ] Agent run reviewed\n- [ ] Tests captured\n- [ ] Diff reviewed\n\n### Evidence\n\n"
                  (format-time-string "%Y-%m-%d %H:%M"))))

(defun gnopon/draft-commit-message ()
  "Create a local commit-message draft from Git status."
  (interactive)
  (let ((buffer (get-buffer-create "*commit-draft*")))
    (with-current-buffer buffer
      (erase-buffer)
      (insert "# Commit Message Draft\n\n")
      (insert "Summary: \n\nDetails:\n\n")
      (insert "```text\n" (gnopon/git-status-short) "\n```\n"))
    (pop-to-buffer buffer)))

(defun gnopon/draft-pr-description ()
  "Create a local PR-description draft from Git status and diff stat."
  (interactive)
  (let ((buffer (get-buffer-create "*pr-draft*")))
    (with-current-buffer buffer
      (erase-buffer)
      (gnopon/markdown-buffer-mode)
      (insert "## Summary\n\n\n## Tests\n\n- [ ] \n\n## Review Notes\n\n```text\n")
      (insert (gnopon/git-status-short))
      (insert "\n```\n\n```text\n")
      (insert (gnopon/git-diff-stat))
      (insert "\n```\n"))
    (pop-to-buffer buffer)))

(define-key gnopon-map (kbd "a c") #'gnopon/agent-context)
(define-key gnopon-map (kbd "a s") #'gnopon/agent-shell)
(define-key gnopon-map (kbd "a t") #'gnopon/insert-agent-task)
(define-key gnopon-map (kbd "a m") #'gnopon/draft-commit-message)
(define-key gnopon-map (kbd "a p") #'gnopon/draft-pr-description)
(define-key gnopon-map (kbd "a r") #'gnopon/review-agent-diff)
(define-key gnopon-map (kbd "a l") #'gnopon/capture-command-log)
(define-key gnopon-map (kbd "a n") #'gnopon/start-agent-session)
(define-key gnopon-map (kbd "a i") #'gnopon/agent-session-index)
(define-key gnopon-map (kbd "a h") #'gnopon/open-agent-handoff)
(define-key gnopon-map (kbd "a H") #'gnopon/write-agent-handoff)
(define-key gnopon-map (kbd "a /") #'gnopon/search-agent-sessions)
(define-key gnopon-map (kbd "a d") #'gnopon/close-agent-session)

(use-package gptel
  :commands (gptel gptel-send)
  :custom
  (gptel-default-mode 'gfm-mode)
  :config
  (when (fboundp 'gptel-make-ollama)
    (setq gptel-model "llama3.1"
          gptel-backend (gptel-make-ollama "Ollama"
                          :host "localhost:11434"
                          :stream t
                          :models '("llama3.1" "qwen2.5-coder" "mistral")))))

(provide 'gnopon-agents)
;;; gnopon-agents.el ends here
