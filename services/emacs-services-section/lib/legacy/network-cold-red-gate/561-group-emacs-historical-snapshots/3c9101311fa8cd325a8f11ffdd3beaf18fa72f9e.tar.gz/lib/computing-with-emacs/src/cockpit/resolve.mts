/**
 * cockpit/resolve — the pure morphisms from config to plan, and to an Emacs call.
 *
 * `resolveCockpit` is the heart of the package: a cockpit config plus a request
 * (a chosen agent, a cwd, optionally a bound session) becomes a fully-resolved
 * `CockpitPlan` — the chat pane and its monitor panes, every path made absolute.
 * When a session is bound, the chat pane is namespaced and tinted by the session's
 * persona, carries the session's identity env, and a leading "world" monitor pane
 * holds the session's persona card, so each session is its own character.
 * `emacsInvocation` computes the argv that launches an Emacs against an init dir.
 */
import { isAbsolute, resolve as resolvePath } from "node:path";
import {
  agentById,
  defaultAgent,
  streamsFor,
  type CockpitConfig,
} from "./cockpit-config.mjs";
import type { AgentEndpoint } from "./agent-endpoint.mjs";
import type { CockpitPane, CockpitPlan } from "./cockpit-plan.mjs";
import { personaSlug } from "./persona.mjs";
import { sessionEnv, shortSessionId, type CockpitSession } from "./session.mjs";

/** Resolve a possibly-relative path against an absolute base. */
function under(base: string, path: string): string {
  return isAbsolute(path) ? path : resolvePath(base, path);
}

/** Render a session's persona card — its sense of who it is in this world. */
export function personaCard(session: CockpitSession, agent: AgentEndpoint, cwd: string): string {
  const persona = session.persona;
  return [
    `# ${persona.glyph} ${persona.name}`,
    "",
    `A ${agent.label} session with its own sense of the world.`,
    "",
    `- persona: \`${persona.name}\``,
    `- glyph: \`${persona.glyph}\``,
    `- colour: \`${persona.color}\``,
    `- agent: \`${agent.id}\` (${agent.label})`,
    `- session: \`${session.id}\``,
    `- cwd: \`${cwd}\``,
    "",
    "## Identity env",
    "",
    ...Object.entries(sessionEnv(session)).map(([key, value]) => `- \`${key}=${value}\``),
    "",
    "This session is not the generic \"claude\"; it is itself. Its env identity is",
    "carried into the chat process so the harness can scope this session's world.",
    "",
  ].join("\n");
}

/** The buffer prefix for a chat/monitor pane, namespaced by session when bound. */
function paneStem(agent: AgentEndpoint, session: CockpitSession | undefined): string {
  if (session === undefined) return `cwe-chat:${agent.id}`;
  return `${agent.id}·${personaSlug(session.persona)}·${shortSessionId(session.id)}`;
}

/** Merge the env layers: config-wide, then agent, then session identity. */
function chatEnv(
  config: CockpitConfig,
  agent: AgentEndpoint,
  session: CockpitSession | undefined,
): Record<string, string> {
  return {
    ...(config.env ?? {}),
    ...(agent.env ?? {}),
    ...(session === undefined ? {} : sessionEnv(session)),
  };
}

/** Build the chat pane for AGENT in CWD, bound to SESSION when present. */
function chatPane(
  config: CockpitConfig,
  agent: AgentEndpoint,
  cwd: string,
  session: CockpitSession | undefined,
): CockpitPane {
  const chatCwd = agent.cwd === undefined ? cwd : under(cwd, agent.cwd);
  const stem = paneStem(agent, session);
  const env = chatEnv(config, agent, session);
  return {
    id: `chat:${session?.id ?? agent.id}`,
    role: "chat",
    label: session === undefined ? agent.label : `${agent.label} · ${session.persona.name}`,
    buffer: `*${stem}*`,
    kind: agent.kind,
    command: agent.command,
    args: agent.args ?? [],
    cwd: chatCwd,
    ...(Object.keys(env).length === 0 ? {} : { env }),
    ...(session === undefined ? {} : { persona: session.persona }),
  };
}

/** The leading "world" pane for a session: its persona card. */
function worldPane(agent: AgentEndpoint, cwd: string, session: CockpitSession): CockpitPane {
  return {
    id: `world:${session.id}`,
    role: "monitor",
    label: `${session.persona.glyph} ${session.persona.name} — world`,
    buffer: `*${paneStem(agent, session)}·world*`,
    kind: "world",
    content: personaCard(session, agent, cwd),
    persona: session.persona,
  };
}

/** Build the stream monitor panes AGENT watches, resolved against CWD. */
function streamPanes(config: CockpitConfig, agent: AgentEndpoint, cwd: string): readonly CockpitPane[] {
  return streamsFor(config, agent).map((stream): CockpitPane => ({
    id: `monitor:${stream.id}`,
    role: "monitor",
    label: stream.label,
    buffer: `*cwe-monitor:${stream.id}*`,
    kind: stream.kind,
    ...(stream.path === undefined ? {} : { path: under(cwd, stream.path) }),
    ...(stream.command === undefined ? {} : { streamCommand: stream.command }),
  }));
}

/** A request to resolve a cockpit: which agent, where, and (optionally) bound session. */
export interface ResolveRequest {
  /** the chosen agent id; the default agent when omitted. */
  readonly agentId?: string;
  /** the cockpit working directory (absolutized). */
  readonly cwd: string;
  /** the bound session; when set, the cockpit is session-scoped and persona-tinted. */
  readonly session?: CockpitSession;
}

/** Resolve a cockpit config and a request into a complete window plan. */
export function resolveCockpit(config: CockpitConfig, request: ResolveRequest): CockpitPlan {
  const base = isAbsolute(request.cwd) ? request.cwd : resolvePath(request.cwd);
  const session = request.session;
  const agentId = request.agentId ?? session?.agentId;
  const agent = agentId === undefined ? defaultAgent(config) : agentById(config, agentId);
  if (agent === undefined) throw new RangeError("cockpit config: no agents to resolve");
  const monitors = [
    ...(session === undefined ? [] : [worldPane(agent, base, session)]),
    ...streamPanes(config, agent, base),
  ];
  return {
    kind: "computing-with-emacs.cockpit-plan",
    agentId: agent.id,
    label: agent.label,
    cwd: base,
    ...(session === undefined ? {} : { session }),
    chat: chatPane(config, agent, base, session),
    monitors,
  };
}

/** A request to launch an Emacs as a cockpit host against an init directory. */
export interface EmacsInvocationRequest {
  /** the package init directory (passed as `--init-directory`). */
  readonly initDirectory: string;
  /** the directory Emacs should treat as `default-directory` (passed as `--chdir`). */
  readonly cwd?: string;
  /** elisp forms to evaluate after startup (each passed as `--eval`). */
  readonly eval?: readonly string[];
  /** extra raw arguments appended verbatim. */
  readonly args?: readonly string[];
}

/** Compute the argv (after `emacs`) that launches a package as an Emacs cockpit. */
export function emacsInvocation(request: EmacsInvocationRequest): readonly string[] {
  const evals = (request.eval ?? []).flatMap((form) => ["--eval", form]);
  return [
    "--init-directory",
    request.initDirectory,
    ...(request.cwd === undefined ? [] : ["--chdir", request.cwd]),
    ...evals,
    ...(request.args ?? []),
  ];
}
