/**
 * cockpit/agent-endpoint — a chat agent the cockpit can drive in a live pane.
 *
 * An agent endpoint is the data behind the *chat pane*: the external program the
 * cockpit runs in a terminal buffer (a Claude CLI, a Codex CLI, an OpenAI TUI).
 * It names which streams to monitor beside it (`streamIds`), so the chooser and
 * the pane plan are projections of this carrier, not of hard-coded knowledge.
 */

/** Whether the chat program is a line CLI or a full-screen terminal UI. */
export type AgentKind = "cli" | "tui";

/** A chat agent endpoint: the program run in the cockpit's chat pane. */
export interface AgentEndpoint {
  /** stable id, used by the chooser and `resolve-cockpit --agent`. */
  readonly id: string;
  /** human label shown in the chooser and on the chat pane. */
  readonly label: string;
  /** cli (line) or tui (full-screen) — drives terminal handling. */
  readonly kind: AgentKind;
  /** the executable program (resolved on PATH by the realizer). */
  readonly command: string;
  /** arguments passed to the program. */
  readonly args?: readonly string[];
  /** working directory override; defaults to the cockpit cwd when omitted. */
  readonly cwd?: string;
  /** optional one-line description shown in the chooser. */
  readonly description?: string;
  /** ids of the streams to monitor beside this agent (order = pane order). */
  readonly streamIds?: readonly string[];
  /** environment variables to export to this agent's chat process. */
  readonly env?: Readonly<Record<string, string>>;
}

/** Type guard for a plausible agent endpoint carrier. */
export function isAgentEndpoint(value: unknown): value is AgentEndpoint {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return false;
  const record = value as Record<string, unknown>;
  return (
    typeof record["id"] === "string" &&
    typeof record["label"] === "string" &&
    typeof record["command"] === "string"
  );
}
